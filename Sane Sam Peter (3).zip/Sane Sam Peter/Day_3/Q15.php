<?php
$n=5;
for($i=1;$i<=$n;$i++){
    for($j=1;$j<=$i;$j++){
            echo "&nbsp;".$j;
    }

    for($k=$i-1;$k>=1;$k--){
        echo "&nbsp;".$k;
}
    echo "<br/>";
}


$n=4;
for($i=$n;$i>=1;$i--){
    for($j=1;$j<=$i-1;$j++){
            echo "&nbsp;".$j;
    }
    for($k=$i;$k>=1;$k--){
        echo "&nbsp;".$k;
}
    echo "<br/>";
}

?>