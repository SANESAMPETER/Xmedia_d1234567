<?php
for ($i=5; $i >0 ; $i--) { 
    # code...
  

    for ($j=$i; $j <=5 ; $j++) { 
        # code...
        echo "&nbsp;".$j;
    }

    echo "<br/>";
}


?>