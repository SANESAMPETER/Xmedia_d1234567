<?php
$n=5;
for($i=1;$i<=$n;$i++){
    for($j=1;$j<=$i;$j++){
            echo $j;
    }
    if($i<=4){
        echo "&nbsp";
    }
    for($k=$i;$k>=1;$k--){
        echo $k;
}
    echo "<br>";
}

?>