<?php
$n=5;
for($i=1;$i<=$n;$i++){
    for($j=1;$j<=$i;$j++){
            echo $i."&nbsp";
    }
    echo "<br>";
}
$size=4; $k=6;
for($i=$size;$i>=1;$i--){
   
    for($j=1;$j<=$i;$j++){
            echo $k."&nbsp";
            
    
}
    
    echo "<br>";
    $k=$k+1;
}
?>