<?php
$n=5;
for($i=1;$i<=$n;$i++){
    $a=1;
    for($j=1;$j<=$i;$j++){
            echo $a."&nbsp";
            $a=$a*2;
    }
    $a=$a/4;
    for($k=$i-1;$k>=1;$k--){
        echo $a."&nbsp";
        $a=$a/2;
}
    echo "<br>";
}
?>