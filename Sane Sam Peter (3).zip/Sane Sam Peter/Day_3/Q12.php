<?php

$cr=1; $c=1;
for ($i=1; $i <=5 ; $i++) { 
    # code...

if ($i%2!==0) {
    $reverse = $cr +$c-1;
    # code...
    for ($j=0; $j <$i ; $j++) { 
        # code...
        echo $reverse--."&nbsp;";
        $c++;
    }
}

else {
    for ($j=1; $j <=$i ; $j++) { 
        # code...
        echo $c."&nbsp;";
        $c++;
    }
}
echo "<br/>";
$cr++;
}

?>