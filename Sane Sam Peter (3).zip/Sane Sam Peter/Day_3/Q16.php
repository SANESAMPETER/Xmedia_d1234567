<?php
$n=5;
for($i=1;$i<=$n;$i++){
 $num =$i;
    for($j=1;$j<=$i;$j++){
            echo "&nbsp;".$num;
            $num =$num +1;
        }
        
        $num =$num -2;
    for($k=$i-1;$k>=1;$k--){
        echo "&nbsp;".$num;
        $num = $num -1;
}
    echo "<br/>";
}



for($i=4;$i>=1;$i--){
    $temp =$i;
    for($j=1;$j<=$i;$j++){
            echo "&nbsp;".$temp;
            $temp = $temp +1;
    }
    $temp = $temp -2;
    for($k=$i-1;$k>=1;$k--){
        echo "&nbsp;".$temp;
        $temp = $temp -1;
}
    echo "<br/>";
}

?>