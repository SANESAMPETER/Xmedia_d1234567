<?php
$num=5;
for($i=1;$i<=$num;$i++){
    for($j=$i;$j>=1;$j--){
            echo $j."&nbsp";
    }
    for($k=2;$k<=$i;$k++){
        echo $k."&nbsp";
}
    echo "<br>";
}

for($i=$num-1;$i>=1;$i--){
    for($j=$i;$j>=1;$j--){
            echo $j."&nbsp";
    }
    for($k=2;$k<=$i;$k++){
        echo $k."&nbsp";
}
    echo "<br>";
}
?>