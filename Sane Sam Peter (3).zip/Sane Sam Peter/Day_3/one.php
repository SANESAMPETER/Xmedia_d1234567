<?php
$r=5;
for ($i=0; $i<$r; $i++)

{ 
    # code...
    for ($j=0; $j <=$i; $j++)
     { 
        # code...
        if ($j%2==0) {
            # code...
            echo (1+$j*$r-($j-1)*$j/2+$i-$j)."&nbsp;";
        } 
        else
         {

            # code...
            echo (1+$j*$r-($j-1)*$j/2+$r-1-$i)."&nbsp;";
        }
        

    }  
    
    echo "<br>";
}



?>