<?php
$num =1;
$row =4;

for ($i=1; $i <=$row ; $i++) { 
    # code...
    for ($j=1; $j <=2*$i-1 ; $j++) { 
        # code...
        echo "&nbsp; ".$num * $num ;
    $num++;
    }
echo "<br/>";
}

?>