<?php

$rows = 5;
for ($i=1;$i <=$rows; $i++) { 
    # code...

    for ($j=$i; $j <=$rows; $j++) { 
        # code...
    echo "&nbsp;".$j;
        
    }

    for ($k=1; $k <=$i-1; $k++) { 
        # code...
        echo "&nbsp;".$k;
    }

    echo "<br/>";
}


?>