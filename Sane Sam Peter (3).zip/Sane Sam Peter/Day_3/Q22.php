<?php
$n=5;
echo "0";
echo "<br>";
for($i=$n;$i>=1;$i--){
    for($j=$i;$j<=$n;$j++){
            echo $j;
    }
    echo "0";
    for($k=$n;$k>=$i;$k--){
        echo $k;
}
    echo "<br>";
}
?>