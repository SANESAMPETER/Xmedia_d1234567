<?php
$rows = 5;
for ($i=0; $i <$rows ; $i++) { 
    # code...

    for ($j=0; $j <$rows; $j++) { 
        # code...
        if ($j%2==0) {
            # code...
            echo "&nbsp;".($rows*($j)+$i+1);
        } else {
            # code...
            echo "&nbsp;".(($rows*($j+1))-$i);
        }
        
    }

    echo "<br/>";
}

?>