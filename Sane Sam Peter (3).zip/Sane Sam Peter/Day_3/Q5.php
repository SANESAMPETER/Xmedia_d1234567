<?php
$n=5;
for ($i=$n; $i>=1; $i--) { 
    # code...
    for ($j=$i; $j <=$n ; $j++) { 
        # code...
        echo "&nbsp;".$j;
    }

    for ($j=$n-1; $j >=$i ; $j--) { 
        # code...
        echo "&nbsp;".$j;
    }

    echo "<br/>";
}


for ($i=2; $i <=$n ; $i++) { 
    # code...
    for ($j=$i; $j <=$n ; $j++) { 
        # code...
        echo "&nbsp;".$j;
    }

    for ($j=$n-1; $j>=$i ; $j--) { 
        # code...
        echo "&nbsp;".$j;
    }
    echo "<br/>";
}


?>