<?php

for ($i=0; $i <5 ; $i++) { 
    # code...
    $k=5-$i;
    for ($j=5; $j >0 ; $j--) { 
        # code...
if ($j>$k) {
    # code...
    echo "&nbsp;".$j;
} else {
    # code..
    echo "&nbsp;".$k;
}
    }

    echo "<br/>";   
}

?>