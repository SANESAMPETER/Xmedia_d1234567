<?php

$rows = 9;
for ($i=1;$i <=$rows; $i+=2) { 
    # code...

    for ($j=$i; $j <=$rows; $j+=2) { 
        # code...
    echo "&nbsp;".$j;
        
    }

    for ($k=1; $k <=$i-1; $k+=2) { 
        # code...
        echo "&nbsp;".$k;
    }

    echo "<br/>";
}


?>