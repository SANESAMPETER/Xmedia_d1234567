<?php
$number =1;
for ($i=1; $i <=5; $i++) { 
    # code...
    for ($j=1; $j <=$i ; $j++) { 
        # code...
        while (!isPrime($number)) {
            # code...
        $number ++;
        }
        echo  "&nbsp; ".$number;
        $number++;
    }
    echo "<br/>";
}

// 
function isPrime($number) {

    if ($number<=1) {
        # code...
        return false;
    }

    for ($i=2; $i <=sqrt($number); $i++) { 
        # code...

        if ($number % $i === 0) {
            # code...
            return false;
        }
    }

    return true;
    
}

?>