<?php
$n=5; $a=1;
for($i=1;$i<=$n;$i++){
    for($j=1;$j<=$i;$j++){
        echo "$a"."&nbsp";
        $a=$a+1;
    }
    $b=$a-1;
    for($k=2;$k<=$i;$k++){
        --$b;
        echo "$b"."&nbsp";
    }
    echo "<br>";
}
?>
