<?php
$n=5;
for ($i=1; $i <=$n ; $i++) { 
    # code...
    for ($j=$n; $j >=$i ; $j--) { 
        # code...
        echo $j;
    }

    if($j>=1){
        echo "&nbsp&nbsp";
    }
    $n=5;
    for ($k=$i; $k <=$n ; $k++) { 
        # code...
        echo $k;
    }

    echo "<br/>";
}
?>