<?php

for ($i=1; $i <=5; $i++) { 
    # code...
    for ($j=1; $j <=$i ; $j++) { 
        # code...

        if ($j==4) {
            # code...
            echo "&nbsp;5";
        } elseif ($j==5){
            # code...
            echo "&nbsp;8";
        }
        else {
            echo "&nbsp;".$j;
        }
        
    }

    echo "<br/>";
}

?>