// $(document).ready(function(){
// $("#main-heading").text("Welcome to Jquery");

// var mhcss= $("#heading");

// mhcss.css({
//     "background-color": "lightblue",
// "font-family":"Arial,Sans-seriff",
// "margin":"3px"});


// // ------------------------------------------------------------------------------------
// //                                  Array                                            //
// // ------------------------------------------------------------------------------------
// var fruits =['apple','banana','orange','mango'];
// // var ef = 


// $.each(fruits, function(index, value) {
//     $("#result").css({
//         'background-color':'blue',
//         'background-image': 'linear-gradient(red, yellow)',                      
//         'font-family':'20px',
//         'margin':'3px',
//         'color':'white',
//         'text-align':'center'
//     })
// $('#result').append(value+ '<br>');
// });

// var arrfind =[1,2,3,4,5];
// var even =[];

// $(arrfind).each(function(index,value) {


//     if (value%2 === 0) {
//         even.push(value);
//     }

//     console.log(value);
// });

// // Even Numbers 
// $(even).each(function(index,value1){
// $('#result1').append(`<li>${value1}</li>`);
// console.log('----');

// console.log('|   |');
// console.log(value1);
// console.log('----');

// });

// });


$(document).ready(function(){

// Click event handler for the button.
$("#btn").click(function() {
    // Toggle the button state.
    var buttonState = $("#btn").toggleClass("clicked");

    // Display the appropriate text.
    if (buttonState) {
      $('#btn1').text("The button has been clicked in");
    } else {
      $('#btn1').text("The button has been clicked out");
    }
  });

});





























