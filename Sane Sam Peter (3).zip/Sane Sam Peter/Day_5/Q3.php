<?php

$arr =[10,20,30,40,50];
$sum=0; $count=0;

//  adding each  element 
foreach ($arr as $val) {
    # code...
$sum += $val;
$count++;
}

if ($count>0) {
    # code...
    $average = $sum/$count;
    echo "Average : ".$average;
} else {
    # code...
    echo "The Array is Empty";
}


?>