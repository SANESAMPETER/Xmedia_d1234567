
<?php
echo "6.";
$number=array(2,4,3,7,1,5,9);   
   $target=10;
   foreach($number as $i){
    foreach($number as $j){
        if($i+$j==$target){
        $total=$i+$j;
        echo "$i+$j =$total";
        echo "<br>";
      
        }
    }
   }

?>