<?php

function ReverseArray($array) {
    $start=0; $end=count($array)-1;
    while ($start<$end) {
        # code...
        $temp=$array[$start];// 0
        // echo $temp;
        $array[$start]=$array[$end]; // 0=4 . 
    //    echo  ($array[$start]=$array[$end]);//54
        $array[$end]=$temp; 
        // echo $temp; 12
        $start++;
         $end--;
    }

    return $array;
}

$array = [1,2,3,4,5];
print_r($array);
echo "<br>";
$reverse = ReverseArray($array);
print_r($reverse);

?>