<?php

$array1 = [1,2,3,4,5]; $array2 = [7,2,9,12,15];

function FirstOrder($arr) {
$PreVal = 0;

foreach ($arr as $val) {
if ($val < $PreVal) {
    # code...
    return false;
}
    $PreVal = $val;
}
return true;
}

if (FirstOrder($array1)) {
    # code...
    echo "Array 1 sorted in correct order ";
} else {
    # code...
    echo " Not in Order ";
}

if (FirstOrder($array2)) {
    # code...
    echo "Array 2 sorted in correct order ";
} else {
    # code...
    echo " A2 Not in Order ";
}




?>