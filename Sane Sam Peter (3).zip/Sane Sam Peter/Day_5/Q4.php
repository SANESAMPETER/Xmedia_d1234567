<?php

function MajorityElement($array) { 

    $count = 0;
    $element=null;

foreach ($array as $value) {
if ($count === 0) {
    # code...
$element = $value;
}
$count+=($value === $element)?1:-1;
} // checks the element which are same

$count=0;

foreach ($array as $value) {
    $count+=($value === $element)?1:0;
}
return $count > count($array)/2 ? $element:null;
// 9/2 =4.5 and 4 is answer 4 times repeated
}
$array =[ 3,3,4,2,4,4,2,4,4];
$majority = MajorityElement($array);



if ($majority !== null) {
echo "The Majority Element ".$majority;

} else {
echo "No Majority ";
}


?>