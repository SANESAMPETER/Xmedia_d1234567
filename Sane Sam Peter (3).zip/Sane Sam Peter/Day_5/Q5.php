<?php 

echo "Find Seocnd Largest <br>";

$array=[10, 5 , 8 , 20, 25];
    $Great = $array[1];  $SecondLargest=0;



foreach ($array as $value) {
if ($value > $Great) {
    
    $SecondLargest=$Great;
     $Great = $value;
}

elseif($value > $Great && ($SecondLargest === 0 || $value > $SecondLargest)) {
    $SecondLargest = $value;
}
}




if ($SecondLargest === 0) {
    # code...
    echo "There is no second largest";
} else {
    # code...
    echo "The second largest ".$SecondLargest;
}


?>