<?php
$score = [["Alice" ,95],["Bob", 82], ["Eve", 88]]; 
print_r($score);
// 

$total = 0;
$NumbserOfStudent =0;


foreach ($score as $value) {
$total += $value[1];
$NumbserOfStudent++;
}

if ($NumbserOfStudent > 0) {
    # code...
    $Average = $total/$NumbserOfStudent;
    echo "Average ".$Average;
} else {
    # code...
    echo "No Student scores Available";
}


?>