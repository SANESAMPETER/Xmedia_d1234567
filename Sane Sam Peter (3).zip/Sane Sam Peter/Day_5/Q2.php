<?php


$array  = [1,2,2,3,4,4,5];
$result = Duplicate($array) ;

foreach ($result as $val) {
    echo $val;
}
    
function Duplicate($array) 
{
    $uni_array =[];

    foreach ($array as $value) {
            $isDuplicate = false;
            // echo $value;  //12345
        foreach ($uni_array as $element) {
            // echo $element;
                    if ($value === $element) {
                            $isDuplicate = true;
                break;
            }
        }
        // stores unique value
        if ($isDuplicate === false) {
                    $uni_array[] = $value;
        }
    }
    return $uni_array;
}

?>