<?php

function FindCommon($arr1, $arr2)
{
    $common_arr =[];

    foreach ($arr1 as $value1) {
        # code...
        foreach ($arr2 as $value2) {
            # code...
            if ($value1 == $value2) {
                # code...
                $common_arr[] = $value1;
                break;
            }
        }
    }

    return $common_arr;
 }

 $arr1 = [1,2,3,4,5];
 $arr2 = [7,2,9,12,15];
 $result = FindCommon($arr1, $arr2);
 if ( $result  ) {
    # code...
    echo "Intersection of the two arrays are  ";

    foreach ($result as $value) {
        # code...
        echo $value;
    }
 } else {
    # code...
    echo "No Intersection of the two arrays ";
 }
 

?>