<?php 
$inventory = [
    ["Apple",10],
    ["Banana",15],
    ["Orange",8]
];

$quanity = 0; // Initially is zero
$Wanted = "Orange";

foreach ($inventory as $value) {
    # code...
    if ($value[0] === $Wanted) {
        # code...
        $quanity=$value[1];
        break;

    }
}

echo "Quantity of Wanted $Wanted of the $quanity";
?>

