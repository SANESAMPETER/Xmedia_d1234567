


<?php

$num =5;
for ($i=1; $i <=$num ; $i++) { 
    # code...
    for ($j=1; $j <=$i ; $j++) { 
        # code...
        echo " &nbsp;&nbsp;   ";
    }
      for ($k=$num; $k >=$i; $k--) { 
         # code...
        echo "*  ";
    }
     //   echo "\n";

    echo "<br/>";
}

// *****
//  ****
//   ***
//    **
//     *
?>