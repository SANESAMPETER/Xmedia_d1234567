<?php
echo "<br/>";
$row=5;
for ($i=1; $i <= $row ; $i++) { 
    # code...
    for ($j=1 ; $j <=$row-$i ; $j++) { 
        # code...
        echo " &nbsp;&nbsp;";    }

    for ($k=1; $k <= $i; $k++) { 
        # code...
        echo " &nbsp; ".$i;
    }

    echo "<br/>";
}


?>