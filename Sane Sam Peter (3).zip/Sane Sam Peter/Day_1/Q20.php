<?php
$rows =5;
for ($i=1; $i <=5; $i++) { 
    # code...
    for ($j=1; $j<=$rows-$i; $j++) { 
        # code...
        echo "&nbsp;&nbsp;";
    }

    for ($k=$i; $k >=1; $k--) { 
        # code...
        echo  $k;
    }

    echo "<br/>";
}
?>