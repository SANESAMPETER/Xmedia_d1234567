 <?php
$num =5;
for ($i=1; $i <=$num ; $i++) { 
    # code...
    for ($j=1; $j <=$num-$i ; $j++) { 
        # code...
        echo "  &nbsp;&nbsp;";
    }
    for ($k=1; $k <=$i ; $k++) { 
        # code...
        echo " *";
    }

    echo "<br/>";
}


//         *
//       * *
//     * * *
//   * * * *
// * * * * *
?> 
