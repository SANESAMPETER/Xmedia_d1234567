<?php
echo "<br/>";
$row=5;
for ($i=1; $i <= $row ; $i++) { 
    # code...
    for ($j=1 ; $j <=$row-$i; $j++) { 
        # code...
        echo " &nbsp;&nbsp;&nbsp; ";    }

    for ($k=1; $k <= 2*$i-1 ; $k++) { 
        # code...
        echo "&nbsp; ".$k;
    }

    echo "<br/>";
}


?>