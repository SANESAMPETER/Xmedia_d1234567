<?php
echo "<br/>";

$num =5;
for ($i=1; $i <=$num ; $i++) { 
    # code...
    for ($j=1; $j <=$num-$i ; $j++) { 
        # code...
        echo "  &nbsp;&nbsp;";
    }
    for ($k=1; $k <=$i ; $k++) { 
        # code...
        echo " *";
    }
    
    echo "<br/>";
}


$num =4;
for ($i=1; $i <=$num ; $i++) { 
    # code...
    for ($j=1; $j <=$i ; $j++) { 
        # code...
        echo " &nbsp;&nbsp;    ";
    }
      for ($k=$num; $k >=$i; $k--) { 
         # code...
        echo "* ";
    }
     //   echo "\n";

    echo "<br/>";
}

//         *
//       * *
//     * * *
//   * * * *
// * * * * *
//   * * * * 
//     * * *
//       * *
//         *
?>