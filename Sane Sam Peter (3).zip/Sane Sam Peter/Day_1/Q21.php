<?php

for ($i=1; $i <=5; $i++) { 
    # code...
    for ($j=1; $j <=6-$i ; $j++) { 
        # code...
        echo $i;
    }
    echo "<br/>";
}


// *****
// ****
// ***
// **
// *
?>