<?php

for ($i=5; $i >=1 ; $i--) { 
    # code...
    $k= $i;
    for ($j=1; $j <=5; $j++) { 
        # code...
        if ($k<=5) {
            # code...
            echo $k;    
        }
        else {
            # code...
            echo "5";
        }
        $k++;
        
    }
    echo "<br/>";
}



// 55555
// 45555
// 34555
// 23455
// 12345

?>