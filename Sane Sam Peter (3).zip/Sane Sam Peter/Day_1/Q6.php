<?php
echo "<br/>";
for ($i=1; $i <=5 ; $i++) { 
    # code...
    for ($j=5-$i; $j >=1 ; $j--) { 
        # code...
        echo " &nbsp;";
    }

    for ($k=1; $k <=$i; $k++) { 
        # code...
        echo " &nbsp;*";
    }

    echo "<br/>";
}



//     *
//    ***
//   *****
//  *******
// *********

?>