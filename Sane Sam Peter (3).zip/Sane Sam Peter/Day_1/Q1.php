<?php 
$rows =5;
for ($i=1; $i <=$rows ; $i++) { 
    # code...
    for ($j=1; $j <=$rows ; $j++) { 
        # code...
        echo " * ";
    }
    echo "<br/>";   
}


// * * * * *
// * * * * *
// * * * * *
// * * * * *
// * * * * *
?>