<?php

for ($i=7; $i >=1; $i-=2) { 
    # code...

    for ($j=1; $j <=$i; $j++) { 
        # code...
        echo $j;
    }

    echo "<br/>";
}
?>