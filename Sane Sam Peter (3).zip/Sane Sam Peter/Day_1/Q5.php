<?php

for ($i=0; $i < 5; $i++) { 
    # code...
    for ($j=1; $j <=5-$i ; $j++) { 
        # code...
        echo "&nbsp; *";
    }
    echo "<br/>";
}


// *****
// ****
// ***
// **
// *
?>