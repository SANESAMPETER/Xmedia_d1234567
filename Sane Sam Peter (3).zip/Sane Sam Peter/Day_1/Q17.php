<?php
for ($i=1; $i < 6; $i++) { 

    for ($j=1;$j <=$i;$j++) { 
    
        if ($j%2 == 0) {
        
                echo "0";
        } else {
        
            echo "1";
        }
        

    }
    echo "<br/>";
}
?>