
<?php
$rows=5;
for ($i=1; $i < $rows; $i++) { 
    # code...

    for ($j=1; $j < $rows -$i+1; $j++) { 
        # code...
        echo $j;
    }
    for ($k=1; $k < 2*$i-1; $k++) { 
        # code...
        echo "*";
    }

    for ($j=$rows-$i; $j >=1 ; $j--) { 
        # code...
        echo $j;
    }

    echo "<br/>";
}

?>