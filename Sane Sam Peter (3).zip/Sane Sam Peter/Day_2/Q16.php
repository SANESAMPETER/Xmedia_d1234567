<?php
for ($a=5; $a >=1 ; $a--) { 
    

    for ($b=$a; $b<=5; $b++) { 
  echo "&nbsp; ".$b;
        
    }

    echo "<br/>";
}


?>