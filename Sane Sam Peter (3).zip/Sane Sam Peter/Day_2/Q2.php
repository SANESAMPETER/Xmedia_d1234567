<?php

for ($i=1; $i <=6; $i++) { 
    # code...
    for ($j=1; $j < $i; $j++) { 
        # code...
        echo "&nbsp; ".$j;
    }

echo "<br/>";
}

for ($i=1; $i <6-1; $i++) { 
    # code...
    for ($j=1; $j < 6-$i; $j++) { 
        # code...
        echo "&nbsp; ".$j;
    }

    echo "<br/>";
}


?>