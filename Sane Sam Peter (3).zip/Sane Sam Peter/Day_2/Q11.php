<?php
$n=5;
for ($i=1; $i <=$n; $i++) { 
for ($j=1; $j <=$i ; $j++) { 
    # code...
    echo "&nbsp; ".$j;
}
for ($j=$i-1; $j >0 ; $j--) { 
    # code...
    echo "&nbsp; ".$j;
}

echo "<br/>";
}
?>