<?php

for ($i=0; $i <5 ; $i++) { 
    # code...
    for ($j=0; $j <=$i; $j++) { 
        # code...
        echo "&nbsp; ".Binomial($i,$j);
    }

    echo "<br/>";
}


function Binomial($n, $k) {
    if ($k==0 || $k==$n) {
        # code...
        return 1;
    } else {
        # code...
        return Binomial($n-1,$k-1) + Binomial($n-1, $k);
    }
    
}
?>