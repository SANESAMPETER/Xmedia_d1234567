<?php

for ($i=1; $i <=6; $i++) { 
    # code...
    for ($j=1; $j < $i; $j++) { 
        # code...
        echo "&nbsp; ".$j;
    }

    echo "<br/>";
}

//   1
//   1  2
//   1  2  3
//   1  2  3  4
//   1  2  3  4  5
?>