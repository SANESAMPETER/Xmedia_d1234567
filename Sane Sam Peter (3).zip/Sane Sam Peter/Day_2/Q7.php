<?php
$r=5;
for ($i=$r; $i >=1; $i--) { 
for ($j=5; $j >=$i ; $j--) { 
echo "&nbsp;".$j;
} 
echo "<br/>";
}

?>