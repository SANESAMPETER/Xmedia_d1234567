<?php
$s=5;
for ($i=1; $i <=$s ; $i++) { 
for ($j=$i; $j <=$s; $j++) { 
echo $j;
}
echo "<br/>";
}
for ($a=5; $a >=1 ; $a--) { 
    

    for ($b=$a; $b<=5; $b++) { 
  echo $b;
        
    }

    echo "<br/>";
}

?>