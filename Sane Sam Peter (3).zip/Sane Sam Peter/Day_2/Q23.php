<?php

for ($i=5; $i >=1 ; $i--) { 
    # code...
    $k=$i;
    for ($j=1; $j <=5; $j++) { 
        # code...

        if ($k<=5) {
          echo "&nbsp; ".$k;
            # code...
        } else {
echo "&nbsp; 5";
        }
        $k++;
        


    }


    echo "<br/>";

}

?>