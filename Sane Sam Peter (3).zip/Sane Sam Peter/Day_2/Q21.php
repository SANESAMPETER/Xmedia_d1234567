<?php

for ($i=1; $i <=5; $i++) { 
    # code...
    for ($j=$i; $j <=5 ; $j++) { 
        # code...

        echo "&nbsp; ".$j;
    }

    for ($j=4; $j >=$i; $j--) { 
        # code...
        echo "&nbsp; ".$j;
    }
    echo "<br/>";
}
?>