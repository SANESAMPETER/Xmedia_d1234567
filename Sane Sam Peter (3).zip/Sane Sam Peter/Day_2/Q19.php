<?php
$num=5;
for ($i=1; $i <=$num; $i++) { 

for ($j=1; $j <=$num ; $j++) { 
    
    if ($j==$i) {
        echo "&nbsp;".$i;

            } 
            else
             {
                echo "&nbsp;0";
        
    }
    
}
echo "<br/>";
}
?>