<?php
$s=6;

for ($i=1; $i < $s; $i++) { 
    # code...
for ($j=6-$i; $j >0 ; $j--) { 
    # code...
    echo "&nbsp; ".$j;
}

echo "<br/>";
}

$r=5;
for ($i=1; $i<=$r ; $i++) { 
    # code...
    for ($j=$i; $j >=1 ; $j--) { 
        # code...
        echo "&nbsp; ".$j;
    }

    echo "<br/>";
}
?>