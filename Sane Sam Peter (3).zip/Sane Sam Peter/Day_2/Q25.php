<?php
$num = 1;
for ($i=1; $i <=4; $i++) { 
    # code...
    for ($j=1; $j <=$i ; $j++) { 
        echo "&nbsp; ".$num * $j;
        # code...
    }
    $num++;

echo "<br/>";
}

$n=5;
for ($i=3; $i <=3;$i--) { 
    # code...
    for ($j=1;$j<=$i;$j++) { 
        # code...
        echo "&nbsp; ".$n*$j;
    }
    $n++;
    echo "<br/>";
}
?>