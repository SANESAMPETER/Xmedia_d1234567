<?php
$n=5;
for ($i=1; $i <=$n ; $i++) { 
    # code...
    for ($j=$n; $j>$i ; $j--) { 
        # code...
    echo "&nbsp; 1";
    }

    for ($k=1; $k<=$i;$k++) { 
        # code...
        echo "&nbsp; ".$j;
    }
    echo "<br/>";
}
?>