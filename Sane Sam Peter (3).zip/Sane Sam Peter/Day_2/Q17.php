<?php
for ($i=1; $i <=5 ; $i++) { 
    # code...

    for ($j=1; $j <=$i ; $j++) { 
        # code...
        echo $j;
    }

    for ($j=$i-1; $j >=1 ; $j--) { 
        # code...
        echo $j;
    }
    echo "<br/>";

}
?>