<?php
$k=1;
for ($i=1; $i<=5;$i++) { 
    # code...
$k=$i;
    for ($j=1; $j<=$i; $j++) { 
        # code...
     
        echo "&nbsp; ".$k;
        $k= $k+5-$j;

    }



    echo "<br/>";
}
?>