<?php
for ($i=1; $i <=5; $i++) { 
    # code...
    for ($j=1; $j <=$i ; $j++) { 
        # code...
        echo "&nbsp; ".$j;
    }

    echo "<br/>";
}
?>