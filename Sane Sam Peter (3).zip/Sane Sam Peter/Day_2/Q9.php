<?php
$r=5;

for ($i=1; $i <=$r ; $i++) { 
    # code...
    $c=$i;
    for ($j=$i; $j >=1;$j--) { 
        # code...
   echo "&nbsp; ".$c;
   $c=$c+$r;
    }

    echo "<br/>";
}
?>