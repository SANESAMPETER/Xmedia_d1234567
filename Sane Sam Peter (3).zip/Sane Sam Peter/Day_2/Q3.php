
<?php
$s=5;

for ($i=0; $i <$s; $i++) { 


    for ($j=1; $j <=$s-$i; $j++) { 
        
        echo "&nbsp; ".$j;
    }
    
    echo "<br>";
}

        // $s=5;
    for ($i=1; $i <=$s ; $i++) { 
        # code...
        for ($j=1; $j<=$i; $j++) { 
            
            echo "&nbsp; ".$j;
        }
        
        echo "<br/>";
    }

?>