-- USE sam;
/*
CREATE TABLE Hospital (
    H_id INT PRIMARY KEY,
    H_name VARCHAR(255),
    H_phno VARCHAR(20),
    H_address VARCHAR(500)
);

*/
/*
CREATE TABLE Doctor (
    d_id INT PRIMARY KEY AUTO_INCREMENT,
     H_id INT,
    q_id int,
    spec_id int,
    d_name VARCHAR(255),
    d_gender VARCHAR(10),
    d_phno VARCHAR(20),
    d_email VARCHAR(255),
    d_address VARCHAR(500),
    d_status VARCHAR(20),
    FOREIGN KEY (H_id) REFERENCES hospital(H_id),
        FOREIGN KEY (q_id) REFERENCES qualification(q_id),
        FOREIGN KEY (spec_id) REFERENCES specialist(spec_id)

);
*/


CREATE TABLE Patient (
    p_id INT PRIMARY KEY,
    p_name VARCHAR(255),
    p_gender VARCHAR(10),
    p_phno VARCHAR(20),
    p_email VARCHAR(255),
    p_address VARCHAR(500),
    p_bloodgroup VARCHAR(10),
    p_status VARCHAR(20)
);
INSERT INTO `patient` (`p_id`, `p_name`, `p_gender`,
  `p_phno`, `p_email`, `p_address`, `p_bloodgroup`,
 `p_status`) VALUES ('206', 'kani', 'female', '678910', 'kani@mail.com', 'vdp', 'b+', 'present'), 
 ('207', 'muhammed', 'male', '768910', 'muhammed@mail.com', 'poonamelle', 'a+', 'present'), 
 ('208', 'rajeswari', 'female', '876910', 'rajeswari@mail.com', 'thirumallai nagar', 'o-', 'present'), 
 ('209', 'pradeep', 'male', '910678', 'pradeep@mail.com', 'tambaram', 'ab-', 'present'),
  ('210', 'mohan', 'male', '109678', 'mohan@mail.com', 'arambakkam', 'ba-', 'present');
USE sam;

CREATE TABLE medicine (
mid INT PRIMARY KEY AUTO_INCREMENT,
    m_name VARCHAR(30)
);
INSERT INTO `medicine` (`mid`, `m_name`, `amount`) VALUES
('91', 'med_a', '100'),
('92', 'med_b', '200'),
('94', 'med_d', '400')
, ('95', 'med_e', '500'), 
('96', 'med_f', '600'),
('97', 'med_g', '700'),
('98', 'med_h', '800'), 
('99', 'med_i', '900');

create TABLE department (
dept_id INT PRIMARY KEY AUTO_INCREMENT,
    dept_name VARCHAR(40)
);
INSERT INTO `department` (`dept_id`, `dept_name`) VALUES ('403', 'cardilogy'), ('404', 'general');

use sam;
/*
create TABLE department (
dept_id INT PRIMARY KEY AUTO_INCREMENT,
    dept_name VARCHAR(40)
);  */

/*
CREATE TABLE specialist (
spec_id INT PRIMARY KEY,
 dept_id int,
spec_name varchar(30),
FOREIGN KEY (dept_id) REFERENCES department(dept_id)

);*


CREATE TABLE appointment (
    a_id INT PRIMARY KEY,
    d_id INT,
    p_id INT,
    a_date DATE,
    a_time TIME,
    a_status ENUM('present', 'absent'),
    FOREIGN KEY (d_id) REFERENCES doctor(d_id),
    FOREIGN KEY (p_id) REFERENCES patient(p_id)
);



/*
CREATE table language (
l_id int PRIMARY KEY AUTO_INCREMENT,
l_name varchar(50)
);
INSERT INTO `lang_known` 
(`lk_id`, `d_id`, `l_id`, `lk_status`) 
VALUES ('21', '411', '11', 'present'), 
('22', '411', '12', 'present'), 
('23', '411', '13', 'present'),
('24', '412', '14', 'present'), 
('25', '412', '15', 'present');

CREATE TABLE qualification 
(
q_id int PRIMARY KEY AUTO_INCREMENT,
q_name varchar(50)
);

CREATE TABLE lang_known 
(
lk_id int PRIMARY KEY AUTO_INCREMENT,
    d_id INT,
    l_id int,
    lk_status ENUM('present', 'absent'),
    FOREIGN KEY (d_id) REFERENCES doctor(d_id),
    FOREIGN KEY (l_id) REFERENCES language(l_id)
);


CREATE TABLE qual_doctor 
(
qd_id int PRIMARY KEY AUTO_INCREMENT,
    d_id INT,
    q_id int,
    qd_status ENUM('present', 'absent'),
    FOREIGN KEY (d_id) REFERENCES doctor(d_id),
    FOREIGN KEY (q_id) REFERENCES qualification(q_id)
); 
*/


use sam;

CREATE TABLE payment (
    pay_ID INT PRIMARY KEY AUTO_INCREMENT,
    pay_mode VARCHAR(20),
    d_id INT,
    p_id INT,
    m_id INT,
    amount VARCHAR(40),
    doctor_charge DECIMAL(8, 2) NOT NULL,
    pay_status VARCHAR(30),
    FOREIGN KEY (d_id) REFERENCES doctor(d_id),
    FOREIGN KEY (p_id) REFERENCES patient(p_id),
    FOREIGN KEY (m_id) REFERENCES medicine(mid)
);

INSERT INTO `payment` (`pay_ID`, `pay_mode`, `d_id`, `p_id`, `m_id`, `amount`, `doctor_charge`, `pay_status`) VALUES ('31', 'gpay', '411', '201', '91', '10000', '300', 'done'),
('32', 'paytm', '412', '203', '92', '4000', '300', 'done'), 
('33', 'phonepe', '413', '203', '93', '4999', '400', 'done'),
('34', 'cash', '414', '204', '94', '20000', '500', 'done'),
('35', 'netbanking', '415', '205', '95', '3000', '150', 'done');


// departement to insert 
INSERT INTO `department` (`dept_id`, `dept_name`) VALUES ('401', 'oral_surgery'), ('402', 'ent_care');


// hospital 
INSERT INTO `hospital` (`H_id`, `H_name`, `H_phno`, `H_address`) 
VALUES 
('102', 'sams', '234567891', 'mumbai'), 
('103', 'sams', '345678912', 'chennai'),
 ('104', 'sams', '456789123', 'kochi'), 
 ('105', 'sams', '567891234', 'pune');


 // doctot table
 INSERT INTO `doctor` (`d_id`, `H_id`, `q_id`, `spec_id`, `d_name`, `d_gender`, `d_phno`, `d_email`, `d_address`, `d_status`) VALUES 
 ('411', '101', '301', '801', 'sam', 'male', '12345', 'sane@gmail.com', 'ambattur', 'present'), 
 ('412', '102', '302', '802', 'sampeter', 'male', '23451', 'sampeter@gmail.com', 'pudur', 'present');
 INSERT INTO `doctor` (`d_id`, `H_id`, `q_id`, `dept_id`, `spec_id`, `d_name`, `d_gender`, `d_phno`, `d_email`, `d_address`, `d_date`, `d_status`) VALUES
  ('413', '103', '301', '401', '803', 'sundar', 'male', '345123', 'sundar@gmail.com', 'redhills', '2023-01-26', 'present'), 
  ('414', '102', '301', '402', '802', 'vishal', 'male', '45123', 'vishal@gmail.com', 'annanagar', '2023-03-31', 'present'),
   ('415', '104', '302', '403', '804', 'chella pandy', 'male', '54321', 'cp@mail.com', 'tambaram', '2015-04-10', 'present');

  // specialist

INSERT INTO `specialist` (`spec_id`, `dept_id`, `spec_name`)
 VALUES ('801', '401', 'dentist'), 
 ('802', '402', 'ent_specialist');
 INSERT INTO `specialist` (`spec_id`, `dept_id`, `spec_name`)
  VALUES ('803', '403', 'cardilogist'), 
  ('804', '404', 'physician');

 SELECT d.d_name, s.spec_name
FROM doctor d
JOIN specialist s ON d.d_id = s. 
JOIN department dept ON s.dept_id = dept.dept_id
WHERE dept.dept_name IN ('Dentist', 'ENT');

// appointment 
INSERT INTO `appointment` (`a_id`, `d_id`, `p_id`, `a_date`, `a_time`, `a_status`) VALUES
 ('601', '411', '202', '2023-08-20', '10:43:55', 'present'), 
('602', '412', '201', '2023-08-08', '10:00:00', 'present');
INSERT INTO `appointment` (`a_id`, `d_id`, `p_id`, `a_date`, `disease`, `a_time`, `a_status`)
VALUES ('604', '412', '203', '2023-08-02', 'headache', '12:00:00', 'present');
INSERT INTO `appointment` (`a_id`, `d_id`, `p_id`, `a_date`, `disease`, `a_time`, `book`, `a_status`)
 VALUES ('605', '412', '204', '2023-03-11', 'rashes', '16:17:26', 'dermatologist', 'present');


//patient
INSERT INTO `patient` (`p_id`, `p_name`, `p_gender`, `p_phno`, `p_email`, `p_address`, `p_bloodgroup`, `p_status`) 
VALUES
 ('201', 'sam', 'male', '123456789', 'sam@patient.com', 'chennai', 'o+', 'present'), 
('202', 'peter', 'male', '234567891', 'peter@patient.com', 'kochi', 'a-', 'present');
INSERT INTO `patient` (`p_id`, `p_name`, `p_gender`, `p_phno`, `p_email`, `p_address`, `p_bloodgroup`, `p_status`)
 VALUES ('203', 'john', 'male', '345678912', 'john@patient.com', 'us', 'a-', 'present'), 
('204', 'sika', 'male', '456789123', 'sika@gmail.com', 'samoa', 'b-', 'absent');
INSERT INTO `patient` (`p_id`, `p_name`, `p_gender`, `p_phno`, `p_email`, `p_address`, `p_bloodgroup`, `p_status`) 
VALUES ('205', 'jims', 'female', '567891234', 'jims@patient.com', 'alaska', 'o-', 'present');


// qualification
INSERT INTO `qualification` (`q_id`, `q_name`) VALUES ('301', 'mbbs'), ('302', 'md');

// qualification of doctor
INSERT INTO `qual_doctor` (`qd_id`, `d_id`, `q_id`, `qd_status`) VALUES 
('1', '411', '301', 'present'),
 ('2', '411', '302', 'present'),
 ('3', '412', '301', 'present'), 
 ('4', '412', '301', 'present');
























++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++


 //1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20

//1.
SELECT d_name, spec_name
from doctor,specialist
WHERE doctor.spec_id=specialist.spec_id and spec_name in('Dentist','ent_specialist');
    
//2

SELECT d.d_name, q.q_name
FROM doctor d
JOIN qualification q ON d.q_id = q.q_id
WHERE q.q_name = 'mbbs';

//3. 
SELECT d_name , q_name 
FROM doctor, qualification
WHERE doctor.q_id=qualification.q_id and q_name in ('mbbs','md');

//4.
SELECT H_name , date_paid , SUM(amount) as month  from  hospital
JOIN payment p on hospital.H_id = p.H_id
where  date_paid BETWEEN '2023-08-01' and '2023-08-31';

//5
SELECT H_name , h_address ,  date_paid , SUM(amount) as week  from  hospital
JOIN payment p on hospital.H_id = p.H_id
where  date_paid BETWEEN '2023-08-15' and '2023-08-22';

// 6
SELECT H_name ,  h_address, date_paid , SUM(amount) as year   from  hospital
JOIN payment p on hospital.H_id = p.H_id
where  date_paid BETWEEN '2023-01-01' and '2024-12-31';


//7.
SELECT h_name , h_address ,SUM(amount) AS day
FROM payment ,hospital
WHERE date_paid = CURDATE();

//8
use sam;
SELECT d.d_name as doctorname , 
       p.p_name as patientname , a.a_date as appointdate , 
       a.a_time as appointtime 
       FROM doctor d 
       JOIN appointment a on d.d_id = a.d_id
       JOIN patient p on a.p_id = p.p_id;

       
-- 9.
SELECT h_name , h_address FROM hospital
WHERE h_address in ('chennai','delhi','mumbai');

       // 10. 
       SELECT * FROM patient;
       SELECT p.p_name as patientname, a.disease as disease 
FROM patient p 
JOIN appointment a on p.p_id = a.p_id
WHERE a.disease = 'fever';

--  11
SELECT p_name as PatientName , a.a_date as AppointDate FROM patient
JOIN appointment a on patient.p_id = a.p_id
WHERE a_date BETWEEN '2023-08-01' and '2023-08-31';

--12
SELECT d_name as DoctorName , a.a_date as AppointDate FROM doctor
JOIN appointment a on doctor.d_id = a.d_id
WHERE a_date BETWEEN '2023-08-01' and '2023-08-31';

-- 13
SELECT d_name as DoctorName , SUM(p.doctor_charge) AS doctorcharge FROM doctor d
JOIN payment p on d.d_id = p.d_id 
WHERE date_paid BETWEEN '2023-08-01' and '2023-08-31';


--14

SELECT p_name as PatientName , SUM(p.amount) AS PatientCharges FROM patient d
JOIN payment p on d.p_id = p.p_id 
WHERE date_paid BETWEEN '2023-08-01' and '2023-08-31';



--15
SELECT d_name , l_name FROM doctor
JOIN language l on doctor.l_id = l.l_id
WHERE l.l_name in ('tamil','hindi');


--16

SELECT d.d_name, dpt.dept_name
FROM doctor d
JOIN department dpt ON d.dept_id = dpt.dept_id
WHERE dpt.dept_name IN ('cardilogy', 'general');

-- 17
SELECT p.p_name as patientname , a.disease as disease 
FROM patient p
JOIN appointment a on p.p_id = a.p_id 
WHERE a.book = 'dermatologist';

-- 18
SELECT d.d_name , a.disease as DoctorName FROM doctor d 
join appointment a on d.d_id = a.d_id
WHERE a.disease = 'cold';

-- 19

SELECT  p_name , p_bloodgroup FROM patient WHERE p_bloodgroup = 'a-';

-- 20 
SELECT * FROM doctor WHERE MONTH(d_date)
=4;

++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++




=======================================
use sam;
SELECT * FROM doctor;
SELECT * FROM department;
SELECT * FROM qualification;
SELECT * FROM qual_doctor;


SELECT p.p_name as patientname , a.disease as disease 
FROM patient p
JOIN appointment a on p.p_id = a.p_id 
WHERE a.book = 'dermatologist';

SELECT d.d_name as doctorname , qd.


use sam;

SELECT d.d_name, s.spec_name
FROM doctor d
JOIN specialist s ON d.spec_id = s.spec_id
WHERE s.spec_name IN ('cardilogist', 'physician');




















SELECT * FROM appointment;
SELECT *FROM department;
SELECT * FROM doctor;
SELECT * FROM hospital;
SELECT * FROM LANGUAGE;
SELECT * FROM lang_known;
SELECT * FROM medicine;
SELECT * FROM patient;
SELECT *FROM payment;
SELECT *FROM qualification;
SELECT *FROM qual_doctor;
SELECT * FROM specialist;