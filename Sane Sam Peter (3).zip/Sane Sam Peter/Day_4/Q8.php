<?php
$user = [
    'user' => 'john doe',
    'email' => 'john@example.com'];

// Adding a new element
$user['mobile'] = 12345678;

print_r($user);
?>
