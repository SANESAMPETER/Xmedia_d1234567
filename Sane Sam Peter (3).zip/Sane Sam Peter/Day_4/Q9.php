<?php
  $number=array(10,20,20,10,10,20,5,20);// declared the array 
  $n= count($number); // count of array
    // echo $n;
 $frequncy=array(); // empty array
for($k=0;$k<$n;$k++){   $increment=0;  
 for($v=0;$v<$n;$v++){
            
  if($number[$k]==$number[$v]){
    $increment++;
      }
           
     }
      $frequncy[$number[$k]]=$increment;
    }
    foreach($frequncy as $key=>$value){
        echo "$key=>$value";
        echo "<br>";
    }
?> 