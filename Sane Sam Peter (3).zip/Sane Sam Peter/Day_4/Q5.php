<?php
  // initially take the value and update the element 
function Minimum($numbers) {
    
    
    $least = $numbers[0];    
    foreach ($numbers as $number) {
        if ($number < $least) {
            $least = $number; 
        }
    }
    
    return $least;
}
$numbers = [10, 5, 8, 15, 3, 20];

$minimum = Minimum($numbers);
echo "The minimum element is:" . $minimum;

?>

<?php

function Maximum($numbers1) {
  
    
    $great = $numbers1[0];    
    foreach ($numbers1 as $number) {
        if ($number > $great) {
            $great = $number; 
        }
    }
    
    return $great;
}


$numbers = [10, 5, 8, 15, 3, 20];
$maximum = Maximum($numbers);
echo "The minimum element is: " . $maximum;

  ?>