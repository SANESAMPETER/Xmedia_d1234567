<?php
$arr1=array('c1'=>'Red','c2'=>'Green','c3'=>'White','c4'=>'Black');
$arr2=array('c2','c4');

$cou=count($arr1);
      

    foreach($arr1 as $key=>$values){
        $value=false;
         foreach($arr2 as $key2=>$values2){
            if($key===$values2){
                $value=true;
                break;
            
            }
        }
        if($value==false){
            $res[$key]=$values;
        }
        }
        echo "<br>";
        print_r($res);
        
    
      ?>