<?php
function Merge($array1, $array2) {
    foreach ($array2 as $element) {
        $array1[] = $element; // combine a1 with a2
    }
    return $array1;
}

$array1 = [1, 2, 3];
$array2 = [4, 5, 6];

$array = Merge($array1, $array2);

print_r($array);
?>
