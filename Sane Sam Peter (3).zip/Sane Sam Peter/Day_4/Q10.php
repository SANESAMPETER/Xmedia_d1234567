<?php
  $number=array(2,4,3,6,8,1,7);    $target=10;
   foreach($number as $i){
    foreach($number as $j){
        if($i+$j==$target){
        $total=$i+$j;
        echo "$i+$j =$total";
        echo "<br>";
      
        }
    }
   }

?>