<?php


// foreach for matrix
// row foreach loop
$matrix = [
    [1, 2, 3],
    [4, 5, 6],
    [7, 8, 9]
];

$SumOfRows = [];
foreach ($matrix as $row) {
    $SumOfRow = 0;
    foreach ($row as $element) {
        $SumOfRow += $element;
    }
    $SumOfRows[] = $SumOfRow;
}

$SumOfColumn = [];
$numCols = count($matrix[0]); 
for ($j = 0; $j < $numCols; $j++) {
    $colSum = 0;
    foreach ($matrix as $row) {
        $colSum += $row[$j];
    }
    $SumOfColumn[] = $colSum;
}

echo "Sum of rows: ";
print_r($SumOfRows);

echo "Sum of columns: ";
print_r($SumOfColumn);


?>