<?php
$numbers = array (-2,3,-5,8,-1,10);
$total = 0;
foreach($numbers as $number)
{
  if($number > 0)
    $total += $number;
}
   echo "$total";
?>
