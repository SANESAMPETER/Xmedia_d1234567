<?php
$fruits = ["banana", "apple", "orange"];
echo "1. ";
print_r($fruits);
// first element 
$FirstFruit = 'cherry';
$updated =[];

$updated[] = $FirstFruit;

foreach ($fruits as $fruit) {
    $updated[] = $fruit;
}

print_r($updated);
// $fruits = ["cherry","banana", "apple", "orange"];


?>


<?php
$fruits = ["banana", "apple", "orange"];
echo "2. ";
print_r($fruits);
// first element 
$LastFruit = 'melon';
$updated =[];


foreach ($fruits as $fruit) {
    $updated[] = $fruit;
}
$updated[] = $LastFruit;

print_r($updated);
// $fruits = ["banana", "apple", "orange","melon"];



?>


<?php 
$fruits = ["banana", "apple", "orange"];
$search = "orange";
$Target ; // 

foreach ($fruits as $index => $fruit) {
    if ($fruit === $search) {
        $Target = $index;
        break; // Break the loop as soon as the target is found
    }
}
echo "the orange index ".$index;


?>