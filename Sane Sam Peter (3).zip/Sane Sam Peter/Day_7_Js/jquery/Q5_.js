const Regsub = document.getElementById('regsub');
const todolisttable = document.getElementById('Todolist');
const myform = document.getElementById('myform')

Regsub.addEventListener('click', function (event) {

    event.preventDefault();
    const name = document.getElementById('name').value;
    const gender = document.querySelector('input[name="gender"]:checked');
    const dob = document.getElementById('dob').value;
    const phno = document.getElementById('phno').value;
    const email = document.getElementById('email').value;
    const e_name = document.getElementById('errorname');
    const e_dob = document.getElementById('errordob');
    const e_email = document.getElementById('error_email');
    const e_phone = document.getElementById('errorphno');
   const gendererror= document.getElementById("genderError");
    const currentDate = new Date();
    const Userdate = new Date(dob)
    const selectedCountry = document.getElementById('country').value;
    const countryError = document.getElementById('countryError');


  // Reset all error messages
  e_name.innerHTML = '';
  e_dob.innerHTML = '';
  e_email.innerHTML = '';
  e_phone.innerHTML = '';
  gendererror.innerHTML = '';

    // Validate Name 
    const namePattern = /^[^0-9a-zA-Z\s]*$/;
    if (!name.match(namePattern)) {
        e_name.innerHTML = '<p>Name should not contain alphanumeric characters</p>';
    }
    // validate dog
    if (Userdate >= currentDate) {
        e_dob.innerHTML = "<b>Date Of Birth cannot be found</b>";
        return;
    }
 // Validate Gender
 if (!gender) {
    gendererror.innerHTML = "Please select a gender.";
} else {
 gendererror.innerHTML='';
}



    // Phone Number Validation
    var phoneNumberRegex = /^\d{10}$/;

    if (!phno.match(phoneNumberRegex)) {
        e_phone.innerHTML = "<p>Invalid phone number format (10 digits required)</p>";
    }
    
  // Email Validation
const emailPattern = /\S+@\S+\.\S+/;
if (!email.match(emailPattern)) {
    e_email.innerHTML = '<p>Please enter a valid email address in the format + /p>';
}


// Reset error message
countryError.textContent = '';

// Validate if a country is selected
if (selectedCountry === "") {
    countryError.textContent = 'Please select a country.';
} else {
    // Perform other actions if needed
    // For example, submit the form
    // document.getElementById('myForm').submit();
    alert('Form submitted successfully!');
}


    // Printig in the table

    const newRow = document.createElement('tr')
    newRow.innerHTML = '<td>' + name + '</td>' +
    '<td>' + gender.value + '</td>' +

        '<td>' + dob + '</td>' +
        '<td>' + email + '</td>'+
        '<td>' + phno + '</td>' ;

        
    todolisttable.appendChild(newRow);

    name.value = '';
    dob.value = '';
    phno.value = '';
    email.value = '';


});