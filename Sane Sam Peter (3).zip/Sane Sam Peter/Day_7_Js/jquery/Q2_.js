$(document).ready(function () {
$('#btn').click(function(){
$('#message').toggle();
});
});