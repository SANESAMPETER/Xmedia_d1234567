$(document).ready(function () {
    $('#submit').click(function(event) { 
      event.preventDefault();

      // click , val,html
      
      var name = $("#name").val();
      var date = $("#dob").val();
      var email = $("#email").val();
    
    
      // print the result 
    
      $("#output").html('Your name '+name+', date is '+date+" and email is "+email);
      // $("#output").html('Your name '+name+', date is '+date+" and email is "+email)
      console.log(name,date,email);
    });

    jq
    });



    