$(document).ready(function(){
$("#btn").click(function(){

    alert("This is an alert box")
});

});