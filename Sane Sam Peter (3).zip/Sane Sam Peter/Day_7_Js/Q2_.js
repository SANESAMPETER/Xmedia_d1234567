var button = document.getElementById("mybutton");
var isClicked = false;


// onclick predefined function
//innerhtml 
button.onclick = function() {
  isClicked =!isClicked;

  if (isClicked) {
    button.innerHTML = "button been clicked";
  } else {
    button.innerHTML = "You clicked out";
  }
};
