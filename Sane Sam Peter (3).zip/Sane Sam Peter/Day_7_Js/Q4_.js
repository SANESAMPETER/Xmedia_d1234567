var bg = document.getElementById("bg")

function ColorFun() {
    bg.style.backgroundColor = "cyan";
}