// Submit Button
const submitbtn = document.getElementById('Submitbtn');
// table body
const todolisttable = document.getElementById('Todolist');

// ---> Submit Button
submitbtn.addEventListener('click', function(event) {
      event.preventDefault();

const name = document.getElementById('Name').value;
const age = document.getElementById('Age').value;
const phon = document.getElementById('Phno').value;



// creating a new row for name, age , phno


const newRow = document.createElement('tr')
newRow.innerHTML = '<td>' + name + '</td>' +
                   '<td>' + age + '</td>' +
                   '<td>' + phon + '</td>';


todolisttable.appendChild(newRow);

console.log(name,age,phon);

name.value='';
age.value='';
phon.value='';

});